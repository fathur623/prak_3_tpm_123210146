import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

class Detail extends StatefulWidget {
  final String mealId;

  Detail({required this.mealId});

  @override
  _DetailState createState() => _DetailState();
}

class _DetailState extends State<Detail> {
  Map<String, dynamic> mealDetails = {};

  @override
  void initState() {
    super.initState();
    fetchDetail(widget.mealId);
  }

  Future<void> fetchDetail(String mealId) async {
    final response = await http.get(Uri.parse('https://www.themealdb.com/api/json/v1/1/lookup.php?i=$mealId'));

    if (response.statusCode == 200) {
      setState(() {
        mealDetails = jsonDecode(response.body)['meals'][0];
      });
    } else {
      throw Exception('Failed to load meal details');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (mealDetails.isEmpty) {
      return Center(child: CircularProgressIndicator());
    }

    String mealName = mealDetails['strMeal'];
    String mealThumb = mealDetails['strMealThumb'];
    String mealInstructions = mealDetails['strInstructions'];
    String mealCategory = mealDetails['strCategory'];
    String mealArea = mealDetails['strArea'];
    String mealYoutube = mealDetails['strYoutube'];

    return Scaffold(
      appBar: AppBar(
        title: Text(mealName),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              height: 400.0,
              child: Image.network(
                mealThumb,
                fit: BoxFit.cover,
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        'Category:',
                        style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold),
                      ),
                      SizedBox(width: 8.0),
                      Text(mealCategory, style: TextStyle(fontSize: 16.0)),
                      Spacer(),
                    ],
                  ),
                  SizedBox(height: 8.0),
                  Text(
                    'Area:',
                    style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold),
                  ),
                  Text(mealArea, style: TextStyle(fontSize: 16.0)),
                  SizedBox(height: 16.0),
                  Text(
                    'Instructions:',
                    style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold,),
                  ),
                  Container(
                    width: double.infinity,
                    child: Text(
                      mealInstructions,
                      style: TextStyle(fontSize: 16.0),
                      textAlign: TextAlign.justify,
                    ),
                  ),
                  SizedBox(height: 32.0),
                  if (mealYoutube.isNotEmpty)
                    ElevatedButton(
                      onPressed: () => launchUrl(Uri.parse(mealYoutube)),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                              'Lihat Video',
                              style: TextStyle(fontSize: 16.0, color: Colors.white)
                          ),
                        ],
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.indigo,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}