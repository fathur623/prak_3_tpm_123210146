import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:prak_tpm3/daftar.dart'; // Import the MealsList class

class Kategori extends StatefulWidget {
  @override
  _KategoriState createState() => _KategoriState();
}

class _KategoriState extends State<Kategori> {
  List<dynamic> categories = [];

  @override
  void initState() {
    super.initState();
    fetchKategori();
  }

  Future<void> fetchKategori() async {
    final response = await http.get(Uri.parse('https://www.themealdb.com/api/json/v1/1/categories.php'));

    if (response.statusCode == 200) {
      setState(() {
        categories = jsonDecode(response.body)['categories'];
      });
    } else {
      throw Exception('Failed to load categories');
    }
  }

  void navigateToMeals(String NamaKategori) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => Daftar(NamaKategori: NamaKategori)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Kategori'),
      ),
      body: GridView.builder(
        itemCount: categories.length,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 1,
          childAspectRatio: 1,
          mainAxisSpacing: 6,
          crossAxisSpacing: 6,
        ),
        itemBuilder: (context, index) {
          String NamaKategori = categories[index]['strCategory'];
          String categoryThumb = categories[index]['strCategoryThumb'];
          String description = categories[index]['strCategoryDescription'];
          if (description.length > 300) {
            description = description.substring(0, 300) + "...";
          }

          return GestureDetector(
            onTap: () => navigateToMeals(NamaKategori),
            child: Card(
              child: Column(
                children: [
                  Image.network(categoryThumb),
                  ListTile(
                    title: Text(NamaKategori),
                    subtitle: Text(description),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
