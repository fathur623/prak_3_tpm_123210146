import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:prak_tpm3/detail.dart';

class Daftar extends StatefulWidget {
  final String NamaKategori;

  Daftar({required this.NamaKategori});

  @override
  _DaftarState createState() => _DaftarState();
}

class _DaftarState extends State<Daftar> {
  List<dynamic> meals = [];

  @override
  void initState() {
    super.initState();
    fetchDaftar(widget.NamaKategori);
  }

  Future<void> fetchDaftar(String NamaKategori) async {
    final response = await http.get(Uri.parse(
        'https://www.themealdb.com/api/json/v1/1/filter.php?c=$NamaKategori'));

    if (response.statusCode == 200) {
      setState(() {
        meals = jsonDecode(response.body)['meals'];
      });
    } else {
      throw Exception('Failed to load meals');
    }
  }

  void navigateToMealDetails(String mealId) {
    Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => Detail(mealId: mealId)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Meals for ${widget.NamaKategori}'),
      ),
      body: GridView.builder(
        itemCount: meals.length,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 1,
          childAspectRatio: 1,
          mainAxisSpacing: 6,
          crossAxisSpacing: 6,
        ),
        itemBuilder: (context, index) {
          String mealName = meals[index]['strMeal'];
          if (mealName.length > 40) {
            mealName = mealName.substring(0, 40) + "...";
          }
          String mealThumb = meals[index]['strMealThumb'];
          String mealId = meals[index]['idMeal'];

          return GestureDetector(
            onTap: () => navigateToMealDetails(mealId),
            child: Card(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  AspectRatio(
                    aspectRatio: 1.5,
                    child: Image.network(mealThumb, fit: BoxFit.cover),
                  ),
                  Padding(
                    padding:
                    const EdgeInsets.all(6.0),
                    child: Text(mealName,
                        style: TextStyle(fontSize: 16.0)),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
